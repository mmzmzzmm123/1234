window.onload = function () {
	init();
}

function init() {
	console.info("ruoyi.vip");
}