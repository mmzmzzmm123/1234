# **项目扩展**

## **后台扩展**

`项目扩展`用于收集来自基于[RuoYi](https://gitee.com/y_project/RuoYi)的插件集成或完整项目，由开发者自己维护。如果你有自己或喜欢的项目想出现在列表中，可以发送仓库地址到我的邮箱`346039442@qq.com`..

| 名称                     | 说明                                                    | 地址                                                    | 
| ------------------------ |-------------------------------------------------------- | ------------------------------------------------------- |
| RuoYi-Vue                | RuoYi前后端分离版本                                     | https://github.com/yangzongzhuan/RuoYi-Vue              |
| RuoYi-Cloud              | RuoYi微服务版本                                         | https://github.com/yangzongzhuan/RuoYi-Cloud            |
| RuoYi-fast               | RuoYi单应用版本                                         | https://github.com/yangzongzhuan/RuoYi-fast             |
| RuoYi-Oracle             | RuoYi多模块Oracle版本                                   | https://github.com/yangzongzhuan/RuoYi-Oracle           |
| RuoYi-gzizi              | RuoYi多模块SQLServer版本                                | https://gitee.com/Sxile/RuoYi-Sqlserver                 |
| RuoYi-zbbtest            | RuoYi多模块PostgreSQL版本                               | https://gitee.com/zbbtest/Ruoyi-PostgreSQL              |
| RuoYi-zhangmrit          | 集成通用Mapper OSS模块 JWT 多数据源切面                 | https://gitee.com/zhangmrit/RuoYi                       |
| RuoYi-cloud              | 集成SpringCloud，ant-design-vue、token、redis           | https://gitee.com/zhangmrit/ruoyi-cloud                 |
| RuoYi-Process            | 集成Activiti 6.x工作流版本                              | https://gitee.com/calvinhwang123/RuoYi-Process          |
| RuoYi-plus               | 集成SpringCloud，config配置中心，使用tk.mybatis、lombok | https://gitee.com/aimeng2017/RuoYi-plus/tree/master     |
| RuoYi-cms                | 内容管理系统（包括博客+爬虫+管理后台）                  | https://gitee.com/markbro/ruoyi-plus                    |
| RuoYi-ZhiGeCms           | 内容管理系统（集成邮件,Redis,Solr,淘宝客等）            | https://gitee.com/Getawy/zhige                          |
| RuoYi-liuwy              | 内容管理系统（集成Activiti5,文件管理器等）              | https://gitee.com/liuwy_dlsdys/zhglxt                   |
| RuoYi-wms                | deer-wms自动化立体仓库原料库系统                        | https://gitee.com/GuoJingXun/deer-wms-2                 |
| RuoYi-windpower          | 基于RuoYi风电场监控项目                                 | https://gitee.com/zhangweijrdhcc/windpower              |
| RuoYi-erp                | 基于RuoYi进销存管理系统                                 | https://gitee.com/tanzhi/hxERP                          |
| RuoYi-radius             | 基于RuoYi路由WIFI认证框架                               | https://gitee.com/panweilei/ruoyi-radius                |
| RuoYi-comic              | 漫画网站响应式 集成redis+七牛云存储图片                 | https://gitee.com/far-east-bureau/comic                 |
| RuoYi-seagull            | 测试平台系统（接口自动化、WEB UI自动化、APP自动化）     | https://gitee.com/seagull1985/LuckyFrameWeb             |
| RuoYi-HtxkEmsm           | 高校教学综合平台                                        | https://github.com/hongmaple/HtxkEmsm                   |
| RuoYi-hp                 | 教学教务管理系统                                        | https://gitee.com/wang2834557/hp-jx                     |
| RuoYi-snow               | 集成钉钉与flowable（一体化人事流程系统）                | https://gitee.com/qimingjin/snow                        |
| RuoYi-badcat             | 集成MybatisPlus与Activiti+Bpmnjs、表单编辑器            | https://gitee.com/study_badcat/ry_mp_activiti           |
| RuoYi-EasyUI             | 集成EasyUI前端                                          | https://gitee.com/yanxiuhair/yanxiuhair                 |
| RuoYi-zhaojin            | jfinal版本（mysql/oralce）                              | https://gitee.com/RemoteControl/BB                      |
| RuoYi-Net                | 基于RuoYi开发.Net语言版本                               | https://github.com/liukuo362573/YiShaAdmin              |
| RuoYi-Net-Cms            | 基于RuoYi开发.Net语言Cms版本                            | https://github.com/aprilyush/EasyCMS                    |
| RuoYi-Go                 | 基于RuoYi开发Go语言版本                                 | https://gitee.com/yunjieg/yjgo                          |
| RuoYi-laravel            | 基于RuoYi开发laravel语言版本                            | https://gitee.com/b5net/b5-laravel-cmf                  |
| RuoYi-ES                 | 集成ElasticSearch搜索引擎、RabbitMQ消息中间件           | https://gitee.com/J-LJJ/RuoYi-ES                        |
| RuoYi-JFlow              | JFlow工作流项目集成案例_Java开源项目 RuoYi v4.1.0       | https://gitee.com/kikock/RuoYi-JFlow                    |
| RuoYi-db2                | 集成db2数据库                                           | https://gitee.com/liao_ru_qi/rouyi-db2                  |
| RuoYi-yangzhengze        | 集成activiti工作流                                      | https://gitee.com/yangzhengze/RuoYi/tree/dev2           |
| RuoYi-kbsmdd             | 集成微信扫码点餐系统                                    | https://gitee.com/china-bin/RuoYi-kbsmdd                |
| RuoYi-davidzhe           | 集成微信小程序（婚礼邀请函）                            | https://gitee.com/davidzhe/wedding-invitation-          |
| RuoYi-NutzSite           | 集成CMS、支付宝、微信公众平台、阿里云、高德、七牛云     | https://gitee.com/TomYule/NutzSite.git                  |
| RuoYi-silence            | 集成了lombok和微信公众号开发的基础框架                  | https://github.com/Thinkingcao/silence-boot             |
| RuoYi-RxJob              | 集成任务调度平台xxl-job支持多用户、多项目组管理         | https://gitee.com/haohandongku/RxJob                    |
| RuoYi-NTL                | 主键改为UUID。同时支持Mysql、Oracle多种数据源           | https://gitee.com/NTL-life/ruoyi                        |
| RuoYi-dongcs             | 集成了keycloak sso功能                                  | https://gitee.com/dongcs0126/RuoYi                      |
| RuoYi-okr                | 实现了okr功能                                           | https://gitee.com/cierqiu/royi_okr                      |
| RuoYi-lwslws             | 增加Mina 用户和部门导入 定时备份mysql数据库 邮件发送    | https://gitee.com/lwslws/ry_New                         |
| RuoYi-baha               | RuoYi单应用Oracle版本                                   | https://gitee.com/baha/RuoYi-fast-Oracle                |
| RuoYi-duzunwu512         | Redis实现Session共享多模块（支持Cacheable缓存）         | https://gitee.com/duzunwu512/RuoYi                      |
| RuoYi-panda              | 集成redis-shiro 百度对象存储 JWT openApi 无xml注解      | https://gitee.com/happy-panda/RuoYi                     |
| RuoYi-rycodes            | 去除mybatis修改成Spring JDBCTemplate                    | https://gitee.com/rycodes/ruoyi                         |
| RuoYi-crown              | 将maven改造为gradle、mybatis更换为mybatis puls          | https://github.com/Caratacus/Crown                      |
| RuoYi-dameng             | 集成达梦数据库                                          | https://gitee.com/freetalent/ruoyi-dameng               |
| RuoYi-kingbase           | 集成人大金仓数据库                                      | https://gitee.com/linux-user/ruoyi-kingbase             |
| RuoYi-beetlsql           | beetlsql版本                                            | https://gitee.com/iehyou/ruoyi-beetlsql                 |
| RuoYi-iterking           | 模板引擎改为Beetl                                       | https://gitee.com/tanba/RuoYi-Beetl                     |
| RuoYi-rocketmq           | 集成rocketmq控制台                                      | https://github.com/472732787/RuoYi/tree/ruoyi-rocketmq  |
| RuoYi-cas                | 集成了cas5.3                                            | https://gitee.com/liupsh/ruoyi-cas                      |
| RuoYi-gradle             | 将maven改造为gradle管理项目                             | https://gitee.com/cacoota/RuoYi                         |
| RuoYi-saas               | 增加mybatis-plus、扩展为SAAS平台，支持多租户管理        | https://gitee.com/jinzheyi/yubb-saas                    |
| RuoYi-saas               | 增加消息中间件、扩展为SAAS平台，支持多租户管理          | https://gitee.com/zhangqiangBUG/hello-ruoyi-saas        |
| RuoYi-shiro-redis        | 集成shiro-redis实现Redis集群会话管理（提取码：9cy7）    | https://pan.baidu.com/s/14fcCNqHlFTrJlH05s0P8uA         |
| RuoYi-sharding-jdbc      | 集成sharding-jdbc实现分库分表（提取码：yapx）           | https://pan.baidu.com/s/1qT__oI3oLfI77Dnj76-iIQ         |
| RuoYi-JustAuth           | 集成JustAuth实现第三方授权登录（提取码：yyxi）          | https://pan.baidu.com/s/1hl_VCJpxG5jFU2lNMG08Yw         |
| RuoYi-jwt                | 集成Jwt实现权限登录授权访问（提取码：dss9）             | https://pan.baidu.com/s/1PCUqenL2JhAR2dIKtCwD1Q         |
| RuoYi-app-jwt            | 集成jwt单独模块认证授权访问（提取码：4syh）             | https://pan.baidu.com/s/1_n6UTVOuqXgJ8JM7QkGzZQ         |
| RuoYi-app-redis          | 集成redis实现权限登录授权访问（提取码：5bp9）           | https://pan.baidu.com/s/1Q3ohzYDMi9TT0W1f3Qw8RQ         |
| RuoYi-aj-captcha         | 集成了aj-captcha登录注册滑块验证（提取码：iki2）        | https://pan.baidu.com/s/14L6gW2g8iUV9yUAe9OHkJQ         |
| RuoYi-atomikos           | 多模块分布式事务atomikos-mysql+mysql（提取码：5juq）    | https://pan.baidu.com/s/1CXXebEIOB1rY5_gLxZat6A         |
| RuoYi-mybatisplus        | 集成mybatisplus实现mybatis增强（提取码：r4ve）          | https://pan.baidu.com/s/1y0qNjJUzelxG2MD4vHaWfA         |
| RuoYi-fast-atomikos      | 单应用分布式事务atomikos-mysql+oracle（提取码：cq6a）   | https://pan.baidu.com/s/1s290OyoCcZlBzwlGrMRJdQ         |
| RuoYi-fast-atomikos      | 单应用分布式事务atomikos-mysql+sqlserver                | https://gitee.com/oldx/ruo-yi-fast                      | 
| RuoYi-jsencrypt          | 集成jsencrypt实现密码加密传输方式（提取码：qmxi）       | https://pan.baidu.com/s/1p5CGTI74sfklX0K-XMy9gw         |
| RuoYi-ueditor            | 集成ueditor实现富文本编辑器增强（提取码：qiuf）         | https://pan.baidu.com/s/1uXYkWLyLrlbA7vxv-u8iDw         |
| RuoYi-cas                | 集成cas实现单点登录认证（提取码：jwf8）                 | https://pan.baidu.com/s/1s4POHLLqtus15IzVoLhF2A         |
| RuoYi-quyj               | Mybatis-Plus多模块，基于RuoYi4.0进行修改                | https://gitee.com/clazz/Ruoyi4.0                        |
| RuoYi-theodo             | Mybatis-Plus多模块，基于RuoYi4.0进行修改                | https://gitee.com/theodo/jeefast2.0                     |
| RuoYi-sushengbuyu        | Mybatis-Plus多模块 Lombok插件（支持代码生成）           | https://gitee.com/sushengbuyu/RuoYi                     |
| RuoYi-fast-mybatis-plus  | Mybatis-Plus单应用（支持代码生成）                      | https://gitee.com/easy__/RuoYi-fast.git                 |
| RuoYi-depending-mp       | Mybatis-Plus多模块（支持代码生成）                      | https://gitee.com/dotstable/depending_on_the_framework  |
| RuoYi-sky                | 安全框架Shiro更换为Spring Secutity                      | https://gitee.com/qiu-qian/sky                          |
| RuoYi-file               | 新增文件上传修改预览（提取码：cs12）                    | https://pan.baidu.com/s/1wl0zCMvY6C4R3vRnYAJqgQ         |
| RuoYi-yuejiu             | 动态数据源(从数据中查询并动态创建数据源)                | https://gitee.com/yuejiu/RuoYi                          |
| RuoYi-yiran              | 集成支付、订单、对账、清算、账户管理等功能              | https://github.com/lsl08/yiran                          |
| RuoYi-zouyi              | Redis实现Session共享单应用（提取码：erft）              | https://pan.baidu.com/s/13QFqhcLRIpQhnhRivAgomg         |
| RuoYi-3.1-activiti       | RuoYi多模块工作流版本                                   | https://pan.baidu.com/s/1Omj6GSB7j4xY6H_nfiNHPA         |
| RuoYi-mybatis-plus       | Mybatis-Plus多模块（支持代码生成）                      | https://pan.baidu.com/s/17ZrAuqJMuGkkSwjkNvVHsA         |
| RuoYi-3.2-redis          | RuoYi多模块Redis实现Session的共享（提取码：rz7c）       | https://pan.baidu.com/s/1tPRlL3dLy82qWDYFps4cwg         |
| RuoYi-qiqiim             | RuoYi-fast 与qiqiim layim 的整合项目                    | https://gitee.com/wenhaofan/RuoYi-qiqiim                |
| RuoYi-layui              | 集成layui主题、MybatisPlus、代码生成改造                | https://github.com/kongshanxuelin/ruoyiplus             |
| RuoYi-chenzz             | Layui版本的RuoYi管理系统                                | https://gitee.com/chenzz/RuoYi-fast/tree/ver-layui      |
| RuoYi-flying             | Layui版本的RuoYi管理系统                                | https://gitee.com/flying_stars/ruoyi-layui              |
| RuoYi-shop               | 供货商城系统（包括小程序+API+管理后台）                 | https://gitee.com/guchengwuyue/supplierShop             |
| RuoYi-zhangmrit          | 归属地整合纯真、百度、离线文件ip2region                 | https://gitee.com/zhangmrit/ruoyi-ip2region             |
| RuoYi-print              | 集成Lodop打印插件，实现自定义打印模板                   | https://gitee.com/xgqx89/ruoyi-print                    |
| RuoYi-code-generator     | 若依独立代码生成工具，无需依赖服务器                    | https://gitee.com/lpf_project/code-generator            |
| RuoYi-common-tools       | 若依框架包名修改器                                      | https://gitee.com/lpf_project/common-tools              |
 
 

## **前台扩展**

| 名称                     | 说明                                   | 地址                                                                |
| ------------------------ |--------------------------------------- | ------------------------------------------------------------------- |
| Hplus                    | Hplus（4.1.0后台主题UI框架）           | https://pan.baidu.com/s/1cpDPD39OjF7IVSmPrmE_oA                     |
| inspinia                 | inspinia（2.7.1后台主题UI框架汉化版）  | https://pan.baidu.com/s/1KI4UPf0DFRs0dZW49-05fQ （提取码: nmju）    |
| inspinia                 | inspinia（2.8后台主题bootstrap4.1）    | https://pan.baidu.com/s/1wUR7GmjEfe8NsQJ5geaQbw                     |
| Distpicker               | Distpicker（v2.0.4省市联动三级下拉框） | https://pan.baidu.com/s/1kGCWkUx7nsikcKt8oXj4gQ                     |

 
[//]: # (| RuoYi-iki                | 集成activiti工作流                                      | https://gitee.com/matosiki/RuoYi/tree/activiti          |)
[//]: # (| RuoYi-fast-redis         | Redis实现Session共享单应用（支持开关切换）              | https://pan.baidu.com/s/1wsiOGfPkVYKzeYDvzkZ5wg         |)
[//]: # (| RuoYi-3.3-oracle         | RuoYi多模块Oracle版本（提取码：fwuu）                   | https://pan.baidu.com/s/1S8HZ-GEMmxK3ldOrWKNpug         |)
[//]: # (| RuoYi-wangchl            | 修改从数据源从数据库中直接读取                          | https://gitee.com/qq1319426493/RuoYi                    |)
[//]: # (| RuoYi-3.4-oracle         | RuoYi多模块Oracle版本（提取码：yrv3）                   | https://pan.baidu.com/s/1YS4G5YlnjbP0HcY6OF-WSw         |)
[//]: # (| RuoYi-racsu              | RuoYi多模块Oracle版本                                   | https://gitee.com/racsu/RuoYi-Oracle                    |)
[//]: # (| RuoYi-stone              | SaaS版，支持租户管理，动态数据源管理                    | https://gitee.com/justime/stone.git                     |)
[//]: # (| RuoYi-fanling            | Layui版本的RuoYi管理系统                                | https://gitee.com/ifanling/fanl-galaxy-venus            |)